
package VehicleHiringSystem;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class VehiclePark_12 {
       private ArrayList<Vehicle_12>vehicles;            
       private ArrayList<Vehicle_12>bookedVehicles;                  
       private ArrayList<Vehicle_12>rentedVehicles;

  
       public VehiclePark_12(){
       
   }
       public ArrayList<Vehicle_12>getVehicles(){
        return vehicles;
}
       public void displayVehicles(){
       getVehicles();

    }
    
     public void displayAvailableVehicles(Date start, Date end) {
        ArrayList<Vehicle_12> availableVehicles = new ArrayList<>();
         for (Vehicle_12 vehicle : vehicles) {
            if (vehicle.isAvailable()) {
                availableVehicles.add(vehicle);
            }
        }

        System.out.println("Available Vehicles:");
        for (Vehicle_12 vehicle : availableVehicles) {
            System.out.println(vehicle);
        }
    }
     public void displayAvailableVehicles(Date start, Date end,String vehicleType) {
        ArrayList<Vehicle_12> availableVehicles = new ArrayList<>();
         for (Vehicle_12 vehicle : vehicles) {
            if (vehicle.isAvailable()) {
                availableVehicles.add(vehicle);
            }
        }

        System.out.println("Available Vehicles:");
        for (Vehicle_12 vehicle : availableVehicles) {
            System.out.println(vehicle);
        }
    }
     public void addVehicle(Vehicle_12 vehicle){
         vehicles.add(vehicle);
     }
     public void removeVehicle(Vehicle_12 vehicle){
         if(vehicles.contains(vehicle)){
             vehicles.remove(vehicle);
             
         }
     }
     
    public void bookVehicle(Date startDate, Date endDate) {
   Vehicle_12 vehicle=new Vehicle_12();
    try {
            vehicle.bookMe(startDate, endDate);           
            System.out.println("Vehicle booked.");
       
    } catch (SorryWeDontHaveThatOneException_12 e) {
        System.out.println("No vehicle type available for the specified dates.");
    }
}

public void cancelBooking(Date cancel,Date rental) {
   Vehicle_12 vehicle=new Vehicle_12();
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter the ID of the vehicle to cancel the booking: ");
    int vehicleId = scanner.nextInt();
        if (vehicle.getId() == vehicleId ) {
            try {
                vehicle.cancelMe(cancel,rental);
                System.out.println("Booking canceled");
                return;
            } catch (NoCancellationYouMustPayException_12 e) {
                System.out.println("Can't cancel the booking after the starting date of rental");
                return;
            }
        }
    System.out.println("Invalid vehicle ID");
}

public void rentVehicle(Date startDate, Date endDate, String deliveryLocation, String dropOffLocation) {
   Vehicle_12 vehicle=new Vehicle_12();   
    try {
        vehicle.rentMe(startDate, endDate, deliveryLocation, dropOffLocation);
       
    } catch (SorryWeDontHaveThatOneException_12 e) {
        System.out.println("Sorry, we don't have that vehicle type available for the specified dates.");
    }
}

public void dropVehicle() {
    Vehicle_12 vehicle=new Vehicle_12();
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter the ID of the vehicle to drop: ");
    int vehicleId = scanner.nextInt();
        if (vehicle.getId() == vehicleId ) {
            vehicle.dropMe();
            System.out.println("Vehicle dropped");
            return;
        }
    System.out.println("Invalid vehicle ID");
}

public void load(int additionalLoad) {
   Vehicle_12 vehicle=new Vehicle_12();
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter the ID of the vehicle to load: ");
    int vehicleId = scanner.nextInt();

        if (vehicle.getId() == vehicleId) {
            try {
                vehicle.loadMe(additionalLoad);
                System.out.println("Additional load added");
                return;
            } catch (OverWeightException_12 e) {
                System.out.println("Loading capacity exceeded.");
            }
        
    }

    System.out.println("Invalid vehicle ID");
}


     public void dailyReport(String fileName) {
    try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
        writer.println("Daily Report");
        writer.println("Vehicles:");
        for (Vehicle_12 vehicle : vehicles) {
            writer.println(vehicle.getId() + " - " + vehicle.getPlateNumber());
        }
        writer.println();

        writer.println("Booked Vehicles:");
        for (Vehicle_12 vehicle : bookedVehicles) {
            writer.println(vehicle.getId() + " - " + vehicle.getPlateNumber());
        }
        writer.println();

        writer.println("Rented Vehicles:");
        for (Vehicle_12 vehicle : rentedVehicles) {
            writer.println(vehicle.getId() + " - " + vehicle.getPlateNumber());
        }
   
        writer.println();

        System.out.println("Daily report generated");

    } catch (IOException e) {
        System.out.println("Exception...");
        e.printStackTrace();
    }
     }
  public Date stringToDate(String s) {
    try {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        return formatter.parse(s);
    } catch (Exception ex) {
    System.out.println("Exception!");
    }   
    return null; 
}
}
