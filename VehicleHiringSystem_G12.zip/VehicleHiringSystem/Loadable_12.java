
package VehicleHiringSystem;


public interface Loadable_12 {
    public abstract void loadMe(int additionalLoad) throws OverWeightException_12;
}
