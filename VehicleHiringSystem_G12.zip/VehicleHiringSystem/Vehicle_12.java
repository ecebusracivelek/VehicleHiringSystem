
package VehicleHiringSystem;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


public class Vehicle_12 implements Rentable_12{
    public int id;
    private static int count;
    private final int plateNumber;
    private final int numberOfTires;
    private int dailyFee;
    public boolean available;
    Vehicle_12(){
    plateNumber = 0; 
    numberOfTires = 0;  
    dailyFee = 0; 
    available = false;
    }
public Vehicle_12(int plateNumber, int numberOfTires,int dailyFee,boolean available){
    this.plateNumber=plateNumber;
    this.numberOfTires=numberOfTires;
    this.dailyFee=dailyFee;
    this.available=available;
    id+=count++;
}
 
public int getDailyFee(){
  Scanner scn=new Scanner(System.in);
    System.out.println("Enter the days of using the car: ");
     int numberOfDays=scn.nextInt();
    return numberOfDays*dailyFee;
}
public int getId(){
    return id;
}
public int getCount(){
    return count;
}
public int getPlateNumber(){
    return plateNumber;
}
public int getNumberOfTires(){
    return numberOfTires;
}
public boolean isAvailable(){
    return available;
}
    public void rentMe(Date start,Date end,String deliveryLoc,String dropLoc) throws  SorryWeDontHaveThatOneException_12{

        if(!available){
            throw new  SorryWeDontHaveThatOneException_12("Vehicle is not available");
        }
        else{       
            available = false;
        System.out.println("Vehicle: " + id + " has been rented from " + start + " to " + end +", from "
        + deliveryLoc + " to " + dropLoc);
     }

        }
        public void dropMe() { 
            if(available){ 
                System.out.println("Vehicle is already available");   
            }
                else {
                       available=true;
                       System.out.println("Vehicle: " + id + " has been dropped. Total price: "+getDailyFee());
       
                        }

            }
        }

