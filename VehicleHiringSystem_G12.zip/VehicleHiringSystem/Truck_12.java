
package VehicleHiringSystem;

import java.util.Date;


public class Truck_12 extends Vehicle_12 implements Bookable_12,Loadable_12{
    
    private int loadingCapacity;
    
    public Truck_12(int plateNumber, int numberOfTires,int dailyFee,boolean available, int loadingCapacity){
     super(plateNumber, numberOfTires,dailyFee,available);
     this.loadingCapacity=loadingCapacity;
    }
    public int getLoadingCapacity(){
        return loadingCapacity;
    }
        public void bookMe(Date start,Date end)throws SorryWeDontHaveThatOneException_12{
            if(available){           
             available=false;
         System.out.println("Truck: " + id + " has been booked from " + start + " to " + end );   
         }
         else{
             throw new SorryWeDontHaveThatOneException_12("This truck is not available");
         }
    }

    public void cancelMe(Date cancellation,Date rental)throws NoCancellationYouMustPayException_12 {
      if (cancellation.after(rental)) {
            throw new NoCancellationYouMustPayException_12("Can't cancel booking, rental has already started.");
        }

        if (!available) {
            available = true;
            System.out.println("Booking the truck: " + id + " has been canceled.");
        }
        else {
            throw new NoCancellationYouMustPayException_12("You must pay first!");
        }
    }
  public void loadMe(int additionalLoad)throws OverWeightException_12 {
       
              if(additionalLoad>loadingCapacity){
            throw new OverWeightException_12("Loading capacity is exceeded");
        }
              else{                 
                  System.out.println("Additional load: " + additionalLoad + " has been loaded onto the truck");   
                  loadingCapacity-=additionalLoad;
              }
              }
}
