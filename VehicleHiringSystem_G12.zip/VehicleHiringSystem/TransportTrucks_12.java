
package VehicleHiringSystem;


public class TransportTrucks_12 extends Truck_12{
    
    private boolean goesAbroad;
    
     public TransportTrucks_12(int plateNumber, int numberOfTires,int dailyFee,boolean available,int loadingCapacity, boolean goesAbroad){
     super(plateNumber,numberOfTires,dailyFee,available,loadingCapacity);
     this.goesAbroad=goesAbroad;
     }
     
     public boolean isGoesAbroad(){
         return goesAbroad;
     }
}