
package VehicleHiringSystem;

import java.util.Date;


public interface Rentable_12 {
     public abstract void rentMe(Date start,Date end,String deliveryLocation,String droppingLocation)throws SorryWeDontHaveThatOneException_12;
      public abstract void dropMe();
}
