
package VehicleHiringSystem;

import java.util.Date;


public class Sports_12 extends Car_12 implements Bookable_12 {
    private int horsePower;
     
    public Sports_12(int plateNumber, int numberOfTires,int dailyFee,boolean available, String color, int seatingCapacity, int numOfDoors){
     super(plateNumber, numberOfTires,dailyFee,available,color,seatingCapacity,numOfDoors); 
     this.horsePower=horsePower;
    }
     public int getHorsePower(){
         return horsePower;
                 
     }
        public void bookMe(Date start,Date end) throws SorryWeDontHaveThatOneException_12 {
         if(available){           
             available=false;
         System.out.println("Sports car: " + id + " has been booked from " + start + " to " + end );   
         }
         else{
             throw new SorryWeDontHaveThatOneException_12("This Sports car is not available");
         }
         
        }

    public void cancelMe(Date cancellation,Date rental)throws NoCancellationYouMustPayException_12 {
      if (cancellation.after(rental)) {
            throw new NoCancellationYouMustPayException_12("Can't cancel booking, rental has already started.");
        }

        if (!available) {
            available = true;
            System.out.println("Booking the sports car: " + id + " has been canceled.");
        }
        else {
            throw new NoCancellationYouMustPayException_12("You must pay first!");
        }

    }
}