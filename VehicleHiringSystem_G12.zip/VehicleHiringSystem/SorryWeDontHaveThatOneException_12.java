
package VehicleHiringSystem;


public class SorryWeDontHaveThatOneException_12 extends Exception{
    String msg;
    public SorryWeDontHaveThatOneException_12(String msg){
        this.msg=msg;
    }
}
