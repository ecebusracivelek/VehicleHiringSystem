
package VehicleHiringSystem;


public class OverWeightException_12 extends Exception{
       String msg;
    public OverWeightException_12(String msg){
        this.msg=msg;
    } 
}
