
package VehicleHiringSystem;

import java.util.Date;


public interface Bookable_12 {
 public abstract void bookMe(Date start,Date end)throws SorryWeDontHaveThatOneException_12;
  public abstract void cancelMe(Date cancellation,Date rental) throws NoCancellationYouMustPayException_12;
}
