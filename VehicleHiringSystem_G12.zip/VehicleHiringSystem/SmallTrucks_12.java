
package VehicleHiringSystem;


 public class SmallTrucks_12 extends Truck_12 {
        
    public SmallTrucks_12(int plateNumber, int numberOfTires,int dailyFee,boolean available,int loadingCapacity){     
        super(plateNumber,numberOfTires,dailyFee,available,loadingCapacity);
   
    }
}
