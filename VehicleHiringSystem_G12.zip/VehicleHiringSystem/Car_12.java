
package VehicleHiringSystem;


public class Car_12  extends Vehicle_12{
    private String color;
    private int seatingCapacity;
    private int numOfDoors;
    public Car_12(int plateNumber, int numberOfTires,int dailyFee, boolean available, String color, int seatingCapacity, int numOfDoors){
     super(plateNumber, numberOfTires,dailyFee,available); 
     this.color=color;
     this.seatingCapacity=seatingCapacity;
     this.numOfDoors=numOfDoors;
    }
    public String getColor(){
        return color;
    }
     public int getSeatingCapacity(){
        return seatingCapacity;
    }
      public int getNumOfDoors(){
        return numOfDoors;
    }
      public void setSeatingCapacity(int seatingCapacity){
         this.seatingCapacity=seatingCapacity;
      }
                  
      public void setColor(String color){
         this.color=color;
      }
                                      
      public void setNumOfDoors(int numOfDoors){
         this.numOfDoors=numOfDoors; 
      }
}
