
package VehicleHiringSystem;


public class SUV_12 extends Car_12 {
        private String wd;
        
    public SUV_12(int plateNumber, int numberOfTires,int dailyFee,boolean available, String color, int seatingCapacity, int numOfDoors,int loadingCapacity,String wd){
     super(plateNumber, numberOfTires,dailyFee,available,color,seatingCapacity,numOfDoors); 
     this.wd=wd;
    }
    
    public String getWd(){
        return wd;
    }
}
