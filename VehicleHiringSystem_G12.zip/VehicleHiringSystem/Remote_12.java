
package VehicleHiringSystem;


public abstract class Remote_12 {
    public abstract boolean deliverable();
    public abstract boolean droppable();

}
