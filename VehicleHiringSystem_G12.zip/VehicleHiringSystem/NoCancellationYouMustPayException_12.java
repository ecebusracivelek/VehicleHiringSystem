
package VehicleHiringSystem;


public class NoCancellationYouMustPayException_12 extends Exception {
      String msg;
    public NoCancellationYouMustPayException_12(String msg){
        this.msg=msg;
    }
}
